import React, { ChangeEvent, use, useState, MouseEvent, SyntheticEvent } from 'react'
import { JSX } from 'react/jsx-runtime'

interface Props  {
    onClick: (e: SyntheticEvent) => void;
    search: string;
    handleChange: (e: ChangeEvent<HTMLInputElement>) => void;
}

const Search: React.FC<Props> = ({onClick, search, handleChange}: Props): JSX.Element => {
    
    return (
        <div><input value={search} onChange={(e) => handleChange(e)} />
            <button onClick={(e) => onClick(e)} />
        </div>
    )
}

export default Search