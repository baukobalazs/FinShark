import React from 'react';

type Props = {}

const AddPortfolio = (props: Props) => {
  return (
    <div>AddPortfolio</div>
  )
}

export default AddPortfolio